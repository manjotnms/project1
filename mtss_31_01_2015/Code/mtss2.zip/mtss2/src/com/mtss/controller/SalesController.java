package com.mtss.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mtss.bean.Sales;
import com.mtss.service.sales.SalesUpdations;

@Controller
public class SalesController {

	@RequestMapping(value="/enterSalesData",method=RequestMethod.GET)
	public ModelAndView enterSalesData(HttpServletRequest request){
		System.out.println("In SalesController's Get Method...........");
		setListInSession(request);
		return new ModelAndView("sales_manager","message","Valid Entry");
	}
	
	@RequestMapping(value="/saveSales",method=RequestMethod.POST)
	public ModelAndView saveSales(@ModelAttribute("sales")Sales sales,HttpServletRequest request){	
		SalesUpdations salesUpdates = new SalesUpdations();
		salesUpdates.saveSales(sales);
		setListInSession(request);
		return new ModelAndView("sales_manager","message","Valid Entry");
	}
	
	@RequestMapping(value="/addNewTaxName",method=RequestMethod.GET)
	public ModelAndView addNewTaxName(@RequestParam("taxName")String taxName,HttpServletRequest request){
		SalesUpdations salesUpdates = new SalesUpdations();
		salesUpdates.addNewTax(taxName);
		setListInSession(request);
		return new ModelAndView("sales_manager","message","Valid Entry");
	}
	
	@RequestMapping(value="/deleteTaxRequest",method=RequestMethod.GET)
	public ModelAndView deleteTaxRequest(HttpServletRequest request){
		setListInSession(request);
		return new ModelAndView("delete_tax","message","Valid Entry");
	}
	@RequestMapping(value="/deleteTax",method=RequestMethod.GET)
	public ModelAndView deleteTax(HttpServletRequest request){
		SalesUpdations salesUpdates = new SalesUpdations();
		
		String taxName = request.getParameter("taxName");
		salesUpdates.deleteTax(taxName);
		setListInSession(request);
		return new ModelAndView("sales_manager","message","Valid Entry");
	}
	
	private void setListInSession(HttpServletRequest request){
		SalesUpdations salesUpdates = new SalesUpdations();
		List<String> taxesList = salesUpdates.getTaxesList();
		request.getSession().setAttribute("taxesList",taxesList);
	}
}
