package com.mtss.managebeans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ManageBeans {
	static ApplicationContext appCtx = null;
	static{
		appCtx = new ClassPathXmlApplicationContext("Spring-Module.xml");
	}
	
	public static ApplicationContext getContext(){
		return appCtx;
	}
	
	public static Object getRequestBean(String beanName){
		
		return appCtx.getBean(beanName);
	}
}
